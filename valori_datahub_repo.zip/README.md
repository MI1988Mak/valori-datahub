
# VALORI Datahub

Ein einfacher FastAPI-Service, der Zinsdaten, ETF-Daten, Immobilienpreise, Steuerfreibeträge und Wechselkurse simuliert. Bereit zur Nutzung mit Render und ChatGPT CustomGPT-Aktionen.

## Endpunkt

```
GET /data
```

## Beispielparameter

- city
- etf
- status
- country
- from_currency
- to_currency
